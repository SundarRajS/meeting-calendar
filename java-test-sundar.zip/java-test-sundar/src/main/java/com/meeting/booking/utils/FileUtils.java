package com.meeting.booking.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface FileUtils {

	public static Logger logger = LoggerFactory.getLogger(FileUtils.class);

	public static List<String> readInputFile() {

		// String fileName = System.getProperty("user.dir") +
		// "/src/main/resources/meeting.txt";
		InputStream file = FileUtils.class.getClassLoader().getResourceAsStream("/meeting.txt");
		try (InputStreamReader isr = new InputStreamReader(file); BufferedReader br = new BufferedReader(isr)) {
			String line = null;
			List<String> content = new ArrayList<>();
			while ((line = br.readLine()) != null) {
				content.add(line);
			}
			file.close();
			return content;
		} catch (Exception e) {
			logger.error("Exception Occurred in reading the file:" + e.getMessage());
		}
		return null;

	}

}