package com.meeting.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaTestSundarApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaTestSundarApplication.class, args);
	}

}
