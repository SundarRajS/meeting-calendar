package com.meeting.booking.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.meeting.booking.model.Meeting;
import com.meeting.booking.service.MeetingService;


@RestController
@RequestMapping(path = "/", produces = "application/json")
public class MeetingCalendarController {

	@Autowired
	private MeetingService meetingService;

	@GetMapping(path = "/meeting-calendar")
	public ResponseEntity<?> getMeetingCalendar() {
		List<Meeting> meetings= this.meetingService.processMeetingRequests();
		return new ResponseEntity<List<Meeting>>(meetings,HttpStatus.OK);
	}

}
